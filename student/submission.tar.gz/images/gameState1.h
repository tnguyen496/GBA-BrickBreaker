/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 gameState1 gameState1.jpg 
 * Time-stamp: Saturday 04/06/2019, 22:45:58
 * 
 * Image Information
 * -----------------
 * gameState1.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMESTATE1_H
#define GAMESTATE1_H

extern const unsigned short gameState1[38400];
#define GAMESTATE1_SIZE 76800
#define GAMESTATE1_LENGTH 38400
#define GAMESTATE1_WIDTH 240
#define GAMESTATE1_HEIGHT 160

#endif

