/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=5x5 ballPicture ballPicture.png 
 * Time-stamp: Thursday 04/11/2019, 02:51:21
 * 
 * Image Information
 * -----------------
 * ballPicture.png 5@5
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#include "ballPicture.h"

const unsigned short ballPicture[25] =
{
	0x4e0a,0x62af,0x7334,0x62cf,0x522b,0x45e9,0x5e8d,0x6f12,0x5e8e,0x49ea,0x41c8,0x49ea,0x522b,0x4a0a,0x41c8,0x49e9,
	0x45c9,0x41c9,0x41c9,0x45e9,0x4a0a,0x4a0a,0x49ea,0x4a0a,0x4a0a
};

