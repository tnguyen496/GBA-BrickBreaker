/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=5x5 ballPicture ballPicture.png 
 * Time-stamp: Thursday 04/11/2019, 02:51:21
 * 
 * Image Information
 * -----------------
 * ballPicture.png 5@5
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BALLPICTURE_H
#define BALLPICTURE_H

extern const unsigned short ballPicture[25];
#define BALLPICTURE_SIZE 50
#define BALLPICTURE_LENGTH 25
#define BALLPICTURE_WIDTH 5
#define BALLPICTURE_HEIGHT 5

#endif

