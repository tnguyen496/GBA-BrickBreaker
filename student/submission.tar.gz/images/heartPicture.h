/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=10x10 heartPicture heartPicture.png 
 * Time-stamp: Friday 04/12/2019, 00:07:30
 * 
 * Image Information
 * -----------------
 * heartPicture.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HEARTPICTURE_H
#define HEARTPICTURE_H

extern const unsigned short heartPicture[100];
#define HEARTPICTURE_SIZE 200
#define HEARTPICTURE_LENGTH 100
#define HEARTPICTURE_WIDTH 10
#define HEARTPICTURE_HEIGHT 10

#endif

