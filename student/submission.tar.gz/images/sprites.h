/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 sprites sprites.png 
 * Time-stamp: Tuesday 04/09/2019, 15:13:09
 * 
 * Image Information
 * -----------------
 * sprites.png 481@287
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPRITES_H
#define SPRITES_H

extern const unsigned short sprites[138047];
#define SPRITES_SIZE 276094
#define SPRITES_LENGTH 138047
#define SPRITES_WIDTH 481
#define SPRITES_HEIGHT 287

#endif

