/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x10 yellowBrick yellowBrick.png 
 * Time-stamp: Tuesday 04/09/2019, 16:34:12
 * 
 * Image Information
 * -----------------
 * yellowBrick.png 20@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef YELLOWBRICK_H
#define YELLOWBRICK_H

extern const unsigned short yellowBrick[200];
#define YELLOWBRICK_SIZE 400
#define YELLOWBRICK_LENGTH 200
#define YELLOWBRICK_WIDTH 20
#define YELLOWBRICK_HEIGHT 10

#endif

