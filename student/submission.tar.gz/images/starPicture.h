/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 starPicture starPicture.png 
 * Time-stamp: Friday 04/12/2019, 00:07:46
 * 
 * Image Information
 * -----------------
 * starPicture.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARPICTURE_H
#define STARPICTURE_H

extern const unsigned short starPicture[400];
#define STARPICTURE_SIZE 800
#define STARPICTURE_LENGTH 400
#define STARPICTURE_WIDTH 20
#define STARPICTURE_HEIGHT 20

#endif

