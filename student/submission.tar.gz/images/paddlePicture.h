/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=30x5 paddlePicture paddlePicture.png 
 * Time-stamp: Thursday 04/11/2019, 02:58:51
 * 
 * Image Information
 * -----------------
 * paddlePicture.png 30@5
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PADDLEPICTURE_H
#define PADDLEPICTURE_H

extern const unsigned short paddlePicture[150];
#define PADDLEPICTURE_SIZE 300
#define PADDLEPICTURE_LENGTH 150
#define PADDLEPICTURE_WIDTH 30
#define PADDLEPICTURE_HEIGHT 5

#endif

