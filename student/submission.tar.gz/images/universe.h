/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 universe universe.jpg 
 * Time-stamp: Saturday 04/06/2019, 19:57:00
 * 
 * Image Information
 * -----------------
 * universe.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef UNIVERSE_H
#define UNIVERSE_H

extern const unsigned short universe[38400];
#define UNIVERSE_SIZE 76800
#define UNIVERSE_LENGTH 38400
#define UNIVERSE_WIDTH 240
#define UNIVERSE_HEIGHT 160

#endif

