/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x10 redBrick redBrick.png 
 * Time-stamp: Tuesday 04/09/2019, 16:38:07
 * 
 * Image Information
 * -----------------
 * redBrick.png 20@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef REDBRICK_H
#define REDBRICK_H

extern const unsigned short redBrick[200];
#define REDBRICK_SIZE 400
#define REDBRICK_LENGTH 200
#define REDBRICK_WIDTH 20
#define REDBRICK_HEIGHT 10

#endif

