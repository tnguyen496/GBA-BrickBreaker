/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x10 blueBrick blueBrick.png 
 * Time-stamp: Tuesday 04/09/2019, 16:38:21
 * 
 * Image Information
 * -----------------
 * blueBrick.png 20@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLUEBRICK_H
#define BLUEBRICK_H

extern const unsigned short blueBrick[200];
#define BLUEBRICK_SIZE 400
#define BLUEBRICK_LENGTH 200
#define BLUEBRICK_WIDTH 20
#define BLUEBRICK_HEIGHT 10

#endif

