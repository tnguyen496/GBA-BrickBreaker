Brick Breaker
================================================================

Author: Tu Nguyen
Welcome to my Brick Breaker GBA game!
Description:
Brick Breaker is a single player game that using the paddle to bounce the ball and use that ball to break the bricks. This game designed by Nolan Bushnell. The game's objective is using the paddle to bounce the ball and use the ball to break all the bricks without touching the bottom of the game.

Instruction:
Use the arrow keys to move the paddle and always to keep track of the ball and not letting it touch the bottom of the game.You will have 3 lives to break all the bricks without touching the bottom. If you break all the bricks and still have lives, then you win!

Note:
If there no lives left, you lose!

Hint:
Use RESET button to Reset Game

Commands:
GameBoy	Keyboard
Start		Enter
Reset		Backspace
Left		Left Arrow
Right		Right Arrow
Up		Up Arrow
Down		Down Arrow
B		X

